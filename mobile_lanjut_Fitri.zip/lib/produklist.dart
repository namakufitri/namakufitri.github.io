import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProdukList extends StatefulWidget {

  @override
  _ProdukListState createState() => new _ProdukListState();
}

class _ProdukListState extends State<ProdukList> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: AppBar(
        title: Text('Jenis Produk'),
      ),
      
      backgroundColor: Colors.yellow,
      body: Stack(
          children: <Widget>[
            Container(
              padding: EdgeInsets.all(10.0),
              child: ListView(
                children: <Widget>[
                  Center(
                    child: Column(
                      children: <Widget>[
                        _produk1(),
                        _produk2(),
                        _produk3(),
                        _produk4(),
                        _produk5(),



                      ],
                    ),
                  ),
                ],
              ),
            ),

          ]
      ),
    );

  }

            Widget _produk1(){
              return Column(
                children: <Widget>[
                Card(
                  child: Row(
                    children: <Widget>[
                      Image.asset(
                        "assets/lapis.jpg",
                        width: 65.0,
                        height: 130.0,
                      ),

                      Expanded(
                          child: Container(
                            child: Column(
                                children: <Widget>[
                                  Text('Lapis Legit' , style: TextStyle(color: Colors.black)),

                                  Padding(
                                    padding: EdgeInsets.only(top: 5.0),
                                  ),
                                  Text('Tersedia rasa cokelat dan Pandan' , style: TextStyle(color: Colors.black)),

                                  Padding(
                                    padding: EdgeInsets.only(top: 5.0),
                                  ),
                                  Text('Rp 150.000/loyang' , style: TextStyle(color: Colors.blue, fontSize: 20.0)),
                                ],
                            ),

                          ),

                      ),
                    ],
                  ),
                 )
                ],
              );

            }

          Widget _produk2(){
            return Column(
              children: <Widget>[
                Card(
                  child: Row(
                    children: <Widget>[
                      Image.asset(
                        "assets/kain_tapis.jpg",
                        width: 65.0,
                        height: 130.0,
                      ),

                      Expanded(
                        child: Container(
                          child: Column(
                            children: <Widget>[
                              Text('Kain Tapis Lampung' , style: TextStyle(color: Colors.black)),

                              Padding(
                                padding: EdgeInsets.only(top: 5.0),
                              ),
                              Text('Tersedia berbagai motif' , style: TextStyle(color: Colors.black)),

                              Padding(
                                padding: EdgeInsets.only(top: 5.0),
                              ),
                              Text('Rp 250.000-1.000.000' , style: TextStyle(color: Colors.blue, fontSize: 20.0)),
                            ],
                          ),

                        ),

                      ),
                    ],
                  ),
                )
              ],
            );

          }


          Widget _produk3(){
            return Column(
              children: <Widget>[
                Card(
                  child: Row(
                    children: <Widget>[
                      Image.asset(
                        "assets/keripik.jpg",
                        width: 65.0,
                        height: 130.0,
                      ),

                      Expanded(
                        child: Container(
                          child: Column(
                            children: <Widget>[
                              Text('Keripik Pisang Khas Lampung' , style: TextStyle(color: Colors.black)),

                              Padding(
                                padding: EdgeInsets.only(top: 5.0),
                              ),
                              Text('Tersedia berbagai varian rasa' , style: TextStyle(color: Colors.black)),

                              Padding(
                                padding: EdgeInsets.only(top: 5.0),
                              ),
                              Text('Rp 25.000' , style: TextStyle(color: Colors.blue, fontSize: 20.0)),
                            ],
                          ),

                        ),

                      ),
                    ],
                  ),
                )
              ],
            );

          }


            Widget _produk4(){
              return Column(
                children: <Widget>[
                  Card(
                    child: Row(
                      children: <Widget>[
                        Image.asset(
                          "assets/kopi_lampung.jpg",
                          width: 65.0,
                          height: 130.0,
                        ),

                        Expanded(
                          child: Container(
                            child: Column(
                              children: <Widget>[
                                Text('Kopi Lampung' , style: TextStyle(color: Colors.black)),

                                Padding(
                                  padding: EdgeInsets.only(top: 5.0),
                                ),
                                Text('Tersedia Soultans Coffe Lampung Robusta' , style: TextStyle(color: Colors.black)),

                                Padding(
                                  padding: EdgeInsets.only(top: 5.0),
                                ),
                                Text('Rp 40.000' , style: TextStyle(color: Colors.blue, fontSize: 20.0)),
                              ],
                            ),

                          ),

                        ),
                      ],
                    ),
                  )
                ],
              );

            }


            Widget _produk5(){
              return Column(
                children: <Widget>[
                  Card(
                    child: Row(
                      children: <Widget>[
                        Image.asset(
                          "assets/siger.jpg",
                          width: 65.0,
                          height: 130.0,
                        ),

                        Expanded(
                          child: Container(
                            child: Column(
                              children: <Widget>[
                                Text('Siger Lampung' , style: TextStyle(color: Colors.black)),

                                Padding(
                                  padding: EdgeInsets.only(top: 5.0),
                                ),
                                Text('Mahkota khas Lampung' , style: TextStyle(color: Colors.black)),

                                Padding(
                                  padding: EdgeInsets.only(top: 5.0),
                                ),
                                Text('Rp 350.000' , style: TextStyle(color: Colors.blue, fontSize: 20.0)),
                              ],
                            ),

                          ),

                        ),
                      ],
                    ),
                  )
                ],
              );

            }


}
